﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace SiteServer.Service.Core
{
    public class ExecuteManager
    {
        private BackgroundWorker worker = new BackgroundWorker();
        private DispatcherTimer timer = new DispatcherTimer();

        private static MethodInfo REF_METHOD = null;
        private static object REF_OBJECT = null;

        public void Execute()
        {
            worker.DoWork += worker_DoWork;
            //worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            timer.Tick += timer_Tick;
            timer.Interval = new TimeSpan(0, 0, 20);   // 20秒
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ConfigurationManager.DirectoryPath) && !worker.IsBusy)
            {
                worker.RunWorkerAsync();
            }
        }

        //void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        //{
            
        //}

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            string ddlFilePath = ConfigurationManager.GetDDLFilePath(ConfigurationManager.DirectoryPath);
            ExecuteManager.Invoke(ddlFilePath, ConfigurationManager.NAME_SPACE, ConfigurationManager.CLASS_NAME, ConfigurationManager.METHOD_NAME, null);
        }

        private static object Invoke(string ddlFilePath, string nameSpace, string className, string methodName, object[] parameters)
        {
            if (REF_METHOD == null || REF_OBJECT == null)
            {
                if (FileSystemUtils.IsFileExists(ddlFilePath))
                {
                    Assembly appAssembly = Assembly.LoadFrom(ddlFilePath);
                    if (appAssembly != null)
                    {
                        Type type = appAssembly.GetType(nameSpace + "." + className);
                        if (type != null)
                        {
                            REF_METHOD = type.GetMethod(methodName);
                            REF_OBJECT = Activator.CreateInstance(type);
                        }
                    }
                }
            }
            if (REF_METHOD != null && REF_OBJECT != null)
            {
                return REF_METHOD.Invoke(REF_OBJECT, parameters);
            }
            return null;
        }
    }
}
